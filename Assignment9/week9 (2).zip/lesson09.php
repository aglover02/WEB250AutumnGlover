<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// --- Database Connection & Schema Creation ---
$db = new PDO('sqlite::memory:');

$db->exec("
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_fname TEXT,
        bill_lname TEXT,
        phone TEXT,
        email TEXT,
        address TEXT
    );
    
    CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        order_date TEXT,
        total_price REAL,
        comments TEXT,
        status TEXT
    );
    
    CREATE TABLE IF NOT EXISTS order_details (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INTEGER,
        item_name TEXT,
        size TEXT,
        toppings TEXT,
        quantity INTEGER,
        price_per_unit REAL,
        topping_price REAL
    );
");

// --- Handle POST Requests ---
$employee_authenticated = false;

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // If Content-Type is application/json, assume it's an order submission
    if (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false) {
        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || !isset($data['customer'], $data['pizzas'])) {
            http_response_code(400);
            echo json_encode(["error" => "Invalid order data."]);
            exit;
        }
        
        $customer = $data['customer'];
        $pizzas = $data['pizzas'];
        
        // Check if customer exists by phone
        $stmt = $db->prepare('SELECT id FROM customers WHERE phone = :phone');
        $stmt->execute(['phone' => $customer['phone']]);
        $customerRow = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$customerRow) {
            $stmt = $db->prepare('INSERT INTO customers (bill_fname, bill_lname, phone, email, address) VALUES (:fname, :lname, :phone, :email, :address)');
            $stmt->execute([
                'fname'   => $customer['fname'],
                'lname'   => $customer['lname'],
                'phone'   => $customer['phone'],
                'email'   => $customer['email'] ?? '',
                'address' => $customer['address'] ?? ''
            ]);
            $customer_id = $db->lastInsertId();
        } else {
            $customer_id = $customerRow['id'];
        }
        
        // Calculate order totals and insert into orders table
        $subtotal = array_reduce($pizzas, function($sum, $p) { return $sum + $p['price']; }, 0);
        $tax = $subtotal * 0.10;
        $total_price = $subtotal + $tax;
        $stmt = $db->prepare('INSERT INTO orders (customer_id, order_date, total_price, comments) VALUES (:customer_id, :order_date, :total_price, :comments)');
        $stmt->execute([
            'customer_id' => $customer_id,
            'order_date' => date('Y-m-d H:i:s'),
            'total_price' => $total_price,
            'comments' => $customer['comments']
        ]);
        $order_id = $db->lastInsertId();
        
        // Insert each pizza into order_details
        foreach ($pizzas as $pizza) {
            $stmt = $db->prepare('INSERT INTO order_details (order_id, item_name, size, toppings, quantity, price_per_unit, topping_price) VALUES (:order_id, :item_name, :size, :toppings, :quantity, :price_per_unit, :topping_price)');
            $stmt->execute([
                'order_id' => $order_id,
                'item_name' => "Pizza",
                'size' => $pizza['size'],
                'toppings' => implode(", ", $pizza['toppings']),
                'quantity' => $pizza['quantity'],
                'price_per_unit' => $pizza['price'] / $pizza['quantity'],
                'topping_price' => 0
            ]);
        }
        
        echo json_encode(["message" => "Order saved successfully!", "order_id" => $order_id]);
        exit;
    } else {
        // Otherwise, assume it's a normal POST (e.g., employee login form)
        if (isset($_POST['employee_password'])) {
            if ($_POST['employee_password'] === "secret123") {
                $employee_authenticated = true;
            }
        }
        // Do not exit so that the page renders
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pizza Order System</title>
    <!-- Include Google Fonts and your CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jersey+10&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/styles.css">
    <script>
        let order = {
            customer: {},
            pizzas: [],
            totalPrice: 0,
            taxRate: 0.1
        };

        function addPizza() {
            const size = document.getElementById("size").value;
            const toppings = Array.from(document.querySelectorAll('input[name="toppings"]:checked')).map(t => t.value);
            const quantity = parseInt(document.getElementById("quantity").value);
            const basePrice = size === "Small" ? 8 : size === "Medium" ? 12 : 15;
            const toppingPrice = size === "Small" ? 1 : size === "Medium" ? 1.5 : 2;
            const pizzaPrice = (basePrice + toppingPrice * toppings.length) * quantity;
            const pizza = { size, toppings, quantity, price: pizzaPrice };
            order.pizzas.push(pizza);
            updateOrderSummary();
        }

        function updateOrderSummary() {
            order.totalPrice = order.pizzas.reduce((sum, pizza) => sum + pizza.price, 0);
            const tax = order.totalPrice * order.taxRate;
            const totalWithTax = order.totalPrice + tax;
            document.getElementById("order-summary").innerHTML = `
                <h3>Order Summary</h3>
                ${order.pizzas.map((pizza, index) => `
                    <p>Pizza ${index + 1}: ${pizza.size}, ${pizza.toppings.join(", ")} x ${pizza.quantity} - $${pizza.price.toFixed(2)}</p>
                `).join("")}
                <p><strong>Subtotal:</strong> $${order.totalPrice.toFixed(2)}</p>
                <p><strong>Tax (10%):</strong> $${tax.toFixed(2)}</p>
                <p><strong>Total:</strong> $${totalWithTax.toFixed(2)}</p>
                <button type="button" onclick="submitOrder()">Submit Order</button>
            `;
        }

        function submitOrder() {
            order.customer = {
                fname: document.getElementById("fname").value,
                lname: document.getElementById("lname").value,
                address: document.getElementById("address").value,
                phone: document.getElementById("phone").value,
                comments: document.getElementById("comments").value,
                email: document.getElementById("email").value
            };

            fetch("", {  // Submitting to the same file
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(order)
            })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                console.log(data);
            })
            .catch(error => console.error("Error:", error));
        }
    </script>
</head>
<body>
    <h1>Pizza Order System</h1>

    <!-- Customer Information Section -->
    <section id="customer-info">
        <h2>Customer Information</h2>
        <form id="customer-form" onsubmit="event.preventDefault();">
            <p>
                <label for="fname">First Name:</label>
                <input type="text" id="fname" name="fname" required>
            </p>
            <p>
                <label for="lname">Last Name:</label>
                <input type="text" id="lname" name="lname" required>
            </p>
            <p>
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" required>
            </p>
            <p>
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" required>
            </p>
            <p>
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </p>
            <p>
                <label for="comments">Special Notes/Delivery Instructions:</label>
                <textarea id="comments" name="comments"></textarea>
            </p>
        </form>
    </section>

    <!-- Pizza Builder Section -->
    <section id="pizza-builder">
        <h2>Build Your Pizza</h2>
        <div>
            <p>
                <label for="size">Size:</label>
                <select id="size" name="size" required>
                    <option value="Small">Small ($8 base + $1 per topping)</option>
                    <option value="Medium">Medium ($12 base + $1.50 per topping)</option>
                    <option value="Large">Large ($15 base + $2 per topping)</option>
                </select>
            </p>
            <fieldset>
                <legend>Toppings (cost depends on size):</legend>
                <label for="topping-pepperoni">
                    <input type="checkbox" id="topping-pepperoni" name="toppings" value="Pepperoni">
                    Pepperoni ($1 / $1.50 / $2)
                </label><br>
                <label for="topping-mushrooms">
                    <input type="checkbox" id="topping-mushrooms" name="toppings" value="Mushrooms">
                    Mushrooms ($1 / $1.50 / $2)
                </label><br>
                <label for="topping-onions">
                    <input type="checkbox" id="topping-onions" name="toppings" value="Onions">
                    Onions ($1 / $1.50 / $2)
                </label><br>
                <label for="topping-sausage">
                    <input type="checkbox" id="topping-sausage" name="toppings" value="Sausage">
                    Sausage ($1 / $1.50 / $2)
                </label><br>
                <label for="topping-bacon">
                    <input type="checkbox" id="topping-bacon" name="toppings" value="Bacon">
                    Bacon ($1 / $1.50 / $2)
                </label><br>
                <label for="topping-extra-cheese">
                    <input type="checkbox" id="topping-extra-cheese" name="toppings" value="Extra Cheese">
                    Extra Cheese ($1 / $1.50 / $2)
                </label>
            </fieldset>
            <p>
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" value="1" required>
            </p>
            <p>
                <button type="button" onclick="addPizza()">Add Pizza</button>
            </p>
        </div>
    </section>

    <!-- Order Summary Section -->
    <section id="order-summary">
        <h2>Order Summary</h2>
        <p>No pizzas added yet.</p>
    </section>

    <!-- Customer Orders Lookup Section -->
    <section id="customer-orders-section">
        <h2>Your Orders</h2>
        <form method="GET">
            <p>
                <label for="phone_lookup">Enter Phone Number:</label>
                <input type="text" id="phone_lookup" name="phone" required>
                <button type="submit">Check Orders</button>
            </p>
        </form>
        <div id="customer-orders">
            <?php
            if (!empty($_GET['phone'])) {
                $stmt = $db->prepare('
                    SELECT o.id, o.order_date, o.total_price, o.status, od.size, od.toppings, od.quantity 
                    FROM orders o 
                    JOIN order_details od ON o.id = od.order_id 
                    WHERE o.customer_id = (SELECT id FROM customers WHERE phone = :phone)
                ');
                $stmt->execute(['phone' => $_GET['phone']]);
                $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
                if ($orders) {
                    foreach ($orders as $order) {
                        echo "<p>Order ID: {$order['id']}<br>";
                        echo "Date: {$order['order_date']}<br>";
                        echo "Size: {$order['size']}<br>";
                        echo "Toppings: {$order['toppings']}<br>";
                        echo "Quantity: {$order['quantity']}<br>";
                        echo "Total Price: \${$order['total_price']}<br>";
                        echo "Status: {$order['status']}</p>";
                        echo "<hr>";
                    }
                } else {
                    echo "<p>No orders found.</p>";
                }
            }
            ?>
        </div>
    </section>

    <!-- Employee Orders Section -->
    <section id="employee-orders">
        <h2>Current Orders</h2>
        <?php
        function displayEmployeeLoginForm() {
            ?>
            <form method="POST">
                <p>
                    <label for="employee_password">Enter Employee Password:</label>
                    <input type="password" id="employee_password" name="employee_password" required>
                    <button type="submit">Login</button>
                </p>
            </form>
            <?php
        }
        if ($employee_authenticated) {
            echo "<h3>Employee Orders</h3>";
            $stmt = $db->query("
                SELECT o.id AS order_id, o.order_date, o.total_price, o.status, o.comments,
                       c.bill_fname, c.bill_lname, c.phone, c.email, c.address
                FROM orders o
                JOIN customers c ON o.customer_id = c.id
                ORDER BY o.order_date DESC
            ");
            $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if ($orders) {
                echo "<table>";
                echo "<tr><th>Order ID</th><th>Date</th><th>Customer</th><th>Address</th><th>Phone</th><th>Email</th><th>Comments</th><th>Total Price</th><th>Status</th><th>Pizza Details</th></tr>";
                foreach ($orders as $order) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($order['order_id']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['order_date']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['bill_fname'] . " " . $order['bill_lname']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['address'] ?? '') . "</td>";
                    echo "<td>" . htmlspecialchars($order['phone']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['comments']) . "</td>";
                    echo "<td>$" . htmlspecialchars($order['total_price']) . "</td>";
                    echo "<td>" . htmlspecialchars($order['status']) . "</td>";
                    $stmt2 = $db->prepare("SELECT * FROM order_details WHERE order_id = :order_id");
                    $stmt2->execute(['order_id' => $order['order_id']]);
                    $pizzas = $stmt2->fetchAll(PDO::FETCH_ASSOC);
                    echo "<td>";
                    if ($pizzas) {
                        echo "<ul class='list'>";
                        foreach ($pizzas as $pizza) {
                            echo "<li>" .
                                htmlspecialchars($pizza['size']) . " pizza with " .
                                htmlspecialchars($pizza['toppings']) . " x " .
                                htmlspecialchars($pizza['quantity']) .
                                " (Price per unit: $" . htmlspecialchars($pizza['price_per_unit']) . ")" .
                                "</li>";
                        }
                        echo "</ul>";
                    } else {
                        echo "No pizza details available.";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>No orders found.</p>";
            }
        } else {
            displayEmployeeLoginForm();
        }
        ?>
    </section>
</body>
</html>
