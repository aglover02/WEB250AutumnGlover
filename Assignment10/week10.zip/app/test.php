<?php
$db = new \PDO(
    'mysql:host=web250-db;dbname=website',
    'webuser',
    'password',
    [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION]
);


echo $db->getAttribute(\PDO::ATTR_SERVER_VERSION) . PHP_EOL;