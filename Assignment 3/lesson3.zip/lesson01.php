<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jersey+10&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <title>Lesson 1</title>
    <link rel="stylesheet" href="/styles.css">
</head>
<body>
    <h1>Lesson 1</h1>
    <ul class="list">
    <li><?php echo 'Hello Autumn!'; ?></li>
  </ul>
</body>
</html>
